using System;

namespace BlackBelt.Models
{
       public abstract class BaseEntity
    {

    }
}